import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'AnswerOutput.dart';
import 'MainPage.dart';



class Enter_Screen extends StatefulWidget {
  const Enter_Screen({Key? key}) : super(key: key);

  @override
  State<Enter_Screen> createState() => _Enter_ScreenState();
}

class _Enter_ScreenState extends State<Enter_Screen> {
  bool _isLoading = false;
  String? _answer;

  TextEditingController _promptController = TextEditingController();

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  Future<void> callChatGPT(String prompt) async {
    const apiKey = "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";
    const apiUrl = "https://api.openai.com/v1/completions";

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',
    };

    final body = jsonEncode(
      {
        "model": "text-davinci-003",
        'prompt': prompt,
        'max_tokens': 2000, // Adjust as needed
      },
    );
    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: headers,
        body: body,
      );
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        final result = jsonResponse['choices'][0]['text'];
        setState(() {
          _answer = result;
        });
      } else {
        print(
          'Failed to call ChatGPT API: ${response.statusCode} ${response.body}',
        );
      }
    } catch (e) {
      print("Error calling ChatGPT API: $e");
    }
  }

  Future<void> _getAnswer(String prompt) async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    await callChatGPT(prompt);

    // Wait for a while before allowing another request
    await Future.delayed(Duration(seconds: 5));

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("AQ")),
      body: Container(
        padding: EdgeInsets.all(1),
        height: 500,
        width: 360,
        //color: Colors.black,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,

          children: [
            SizedBox(height: 13,),
            TextField(
              controller: _promptController,
              keyboardType: TextInputType.multiline ,
              minLines: 1,
              maxLines: 7,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        width: 3 , color: Colors.black
                    )
                ),
                labelText: "Enter your question",
                border: OutlineInputBorder(
                ),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                side: BorderSide(),
                padding: EdgeInsets.symmetric(
                    horizontal: 40.0, vertical: 10.0),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
              ),

              child: _isLoading
                  ? CircularProgressIndicator()
                  : Text("Get Answer" , style: TextStyle(fontSize: 15),),
              onPressed: _isLoading
                  ? null
                  : () async {
                final prompt = _promptController.text;
                if (prompt.isNotEmpty) {
                  await _getAnswer(prompt);
                  if (_answer != null) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            AnswerOutput(answer: _answer!),
                      ),
                    );
                  }
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
