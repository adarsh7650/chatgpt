
import 'package:flutter/material.dart';
import 'Enter_Screenn.dart';
import 'GC_Screen.dart';


class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AQ"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              onPressed: () {
               Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>  GC_Screen(),
                ));
              },
              icon: Icon(Icons.photo_camera),
              label: Text('Gallery Or Camera'),
              style: ElevatedButton.styleFrom(
                side: BorderSide(),
                padding: EdgeInsets.symmetric(
                    horizontal: 40.0, vertical: 10.0),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
              ),
            ),
            SizedBox(height: 10),
            Divider(),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Enter_Screen()),
                );
              },
              child: Text('Enter the Questions'),
              style: ElevatedButton.styleFrom(
                side: BorderSide(),
                padding: EdgeInsets.symmetric(
                    horizontal: 40.0, vertical: 10.0),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}