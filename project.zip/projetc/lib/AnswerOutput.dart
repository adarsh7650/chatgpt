import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AnswerOutput extends StatefulWidget {
  final String answer;

  const AnswerOutput({required this.answer});

  @override
  _AnswerOutputState createState() => _AnswerOutputState();
}

class _AnswerOutputState extends State<AnswerOutput> {
  String _typingAnswer = "";

  @override
  void initState() {
    super.initState();
    _simulateTyping();
  }

  void _simulateTyping() async {
    for (var i = 0; i <= widget.answer.length; i++) {
      setState(() {
        _typingAnswer = widget.answer.substring(0, i);
      });
      await Future.delayed(Duration(milliseconds: 50)); // Adjust typing speed
    }
  }

  void _copyToClipboard() {
    Clipboard.setData(ClipboardData(text: widget.answer));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Copied to clipboard")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AQ -   Answer"),
        actions: [
          IconButton(
            onPressed: _copyToClipboard,
            icon: Icon(Icons.copy),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(_typingAnswer),
        ),
      ),
    );
  }
}
